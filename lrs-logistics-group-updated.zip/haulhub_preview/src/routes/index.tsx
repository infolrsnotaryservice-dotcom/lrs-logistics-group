import { createFileRoute } from "@tanstack/react-router";
import {
  Search,
  Handshake,
  MessageSquare,
  ClipboardCheck,
  Map,
  FileCheck2,
  Headphones,
  Briefcase,
  Timer,
  FolderCheck,
  Truck,
  Snowflake,
  Layers,
  Package,
  Zap,
  Boxes,
  Ruler,
  Container,
  CheckCircle2,
  ArrowRight,
  Clock,
  Facebook,
  Instagram,
  Linkedin,
  Youtube,
} from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { SiteHeader } from "@/components/site/SiteHeader";
import { ContactSection } from "@/components/site/ContactSection";
import heroTruck from "@/assets/hero-truck.jpg";
import dock from "@/assets/dock.jpg";
import ctaHighway from "@/assets/cta-highway.jpg";
import logoAsset from "@/assets/lrs-logistics-logo.jpeg.asset.json";

const TITLE = "LRS Logistics Group | Freight Dispatching for Owner-Operators";
const DESCRIPTION =
  "Professional freight dispatching for owner-operators and small fleets: load finding, rate negotiation, broker communication, and back-office support.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const SERVICES = [
  { icon: Search, title: "Load Finding", text: "We work the load boards and broker network daily to match freight to your equipment and lanes." },
  { icon: Handshake, title: "Rate Negotiation", text: "We push for better rates on every load so your miles pay what they should." },
  { icon: MessageSquare, title: "Broker Communication", text: "We handle the calls, emails, and check calls so your phone stays quiet on the road." },
  { icon: ClipboardCheck, title: "Load Booking", text: "Confirmed bookings with pickup and delivery details sent straight to you." },
  { icon: Map, title: "Route Planning", text: "Practical routing that considers hours of service, fuel stops, and reload opportunities." },
  { icon: FileCheck2, title: "Rate Confirmation Management", text: "Rate cons reviewed, organized, and tracked for every booked load." },
  { icon: Headphones, title: "Driver Support", text: "A real dispatcher on the other end of the line during business hours." },
  { icon: Briefcase, title: "Back-Office Assistance", text: "Carrier packets, broker setups, and paperwork handled for you." },
  { icon: Timer, title: "Detention & Layover Assistance", text: "We document delays and follow up with brokers on detention and layover pay." },
  { icon: FolderCheck, title: "Document Organization", text: "BOLs, PODs, and rate cons kept organized and easy to find." },
];

const WHY = [
  "Professional dispatch support",
  "Faster communication with brokers",
  "Load search assistance",
  "Rate negotiation on every load",
  "Reduced downtime between loads",
  "Personalized service, not a call center",
  "Reliable, consistent communication",
  "Dedicated support during business hours",
];

const STEPS = [
  { n: "01", title: "Sign Up", text: "Complete your carrier information and dispatch agreement." },
  { n: "02", title: "We Search", text: "Our dispatch team searches available freight that matches your equipment and preferences." },
  { n: "03", title: "We Negotiate", text: "We communicate with brokers and negotiate rates on your behalf." },
  { n: "04", title: "You Haul", text: "You focus on driving while we help manage the dispatching process." },
];

const EQUIPMENT = [
  { icon: Truck, name: "Dry Van", text: "Standard 53' freight — the backbone of general commodity hauling." },
  { icon: Snowflake, name: "Reefer", text: "Temperature-controlled loads for produce, food, and pharma." },
  { icon: Layers, name: "Flatbed", text: "Open-deck freight with securement and tarping requirements." },
  { icon: Ruler, name: "Step Deck", text: "Taller loads that won't clear standard flatbed height limits." },
  { icon: Zap, name: "Power Only", text: "Pull preloaded trailers and keep your tractor earning." },
  { icon: Boxes, name: "Box Truck", text: "Regional and expedited freight for smaller shipments." },
  { icon: Package, name: "Hotshot", text: "Time-sensitive smaller loads on gooseneck and dovetail trailers." },
  { icon: Container, name: "Straight Truck", text: "Local and regional deliveries with liftgate-friendly freight." },
];

const BENEFITS = [
  { title: "Save Time", text: "Stop scrolling load boards at the truck stop. We do the searching." },
  { title: "Find Loads", text: "Consistent freight options that fit your equipment and preferred lanes." },
  { title: "Reduce Empty Miles", text: "We plan the next load before you're empty whenever possible." },
  { title: "Improve Organization", text: "Documents, rate cons, and load history kept in order." },
  { title: "Broker Communication", text: "We handle setups, check calls, and follow-ups on your behalf." },
  { title: "More Road Focus", text: "Less admin, fewer distractions, more attention on driving safely." },
];

const FAQS = [
  { q: "What does a freight dispatcher do?", a: "A freight dispatcher searches for available loads, negotiates rates with brokers, books freight, and handles the paperwork and communication around each load so the driver can focus on hauling." },
  { q: "Do you work with owner-operators?", a: "Yes. Owner-operators and small trucking companies are exactly who we build our service around. Whether you run one truck or a small fleet, you get the same dedicated support." },
  { q: "What types of trucks do you dispatch?", a: "Dry van, reefer, flatbed, step deck, power only, box truck, hotshot, and straight truck. If you run mixed equipment, we dispatch across it." },
  { q: "How does your dispatch service work?", a: "You sign up and complete a dispatch agreement, we learn your preferences and equipment, then we search freight, negotiate rates, and book loads on your behalf while keeping you updated." },
  { q: "How do I get started?", a: "Fill out the contact form with your carrier details and truck type. A dispatcher will reach out during business hours to finish onboarding." },
  { q: "Do you negotiate rates?", a: "Yes. Rate negotiation is part of every load we book. We work brokers for the best rate we can get on the freight available." },
  { q: "Do you communicate with brokers?", a: "Yes. We manage broker setups, booking calls, check calls, and follow-ups including detention and layover claims." },
  { q: "What are your dispatch hours?", a: "Monday through Friday, 8:00 AM to 6:00 PM." },
];

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <main id="home">
        {/* HERO */}
        <section className="relative flex min-h-[92vh] items-center overflow-hidden">
          <img
            src={heroTruck}
            alt="Semi-truck hauling a trailer down an American interstate highway at sunrise"
            width={1920}
            height={1080}
            className="absolute inset-0 size-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
          <div className="container-page relative pt-32 pb-20">
            <p className="eyebrow">Freight Dispatching for Owner-Operators</p>
            <h1 className="mt-5 max-w-4xl text-5xl font-bold leading-[0.95] md:text-7xl">
              Keep Your Truck Moving.{" "}
              <span className="text-gradient-accent">We'll Handle the Dispatching.</span>
            </h1>
            <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
              Professional freight dispatching services designed to help owner-operators and
              trucking companies find quality loads, reduce downtime, and spend more time on the
              road.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <a href="#contact" className="btn-base btn-primary">
                Get Started <ArrowRight className="size-4" aria-hidden />
              </a>
              <a href="#services" className="btn-base btn-outline">
                Our Services
              </a>
            </div>
            <p className="mt-8 inline-flex items-center gap-2 rounded-full border border-border bg-background/60 px-4 py-2 text-sm text-muted-foreground backdrop-blur">
              <Clock className="size-4 text-primary" aria-hidden />
              Dispatch Hours: Monday–Friday | 8:00 AM–6:00 PM
            </p>
          </div>
        </section>

        {/* SERVICES */}
        <section id="services" className="scroll-mt-24 py-24">
          <div className="container-page">
            <p className="eyebrow">Dispatch Services</p>
            <h2 className="mt-4 max-w-3xl text-4xl font-bold md:text-5xl">
              Full-Service Freight Dispatching
            </h2>
            <p className="mt-5 max-w-2xl text-muted-foreground">
              Our goal is simple: reduce the administrative workload sitting on your dashboard so
              you can focus on driving and growing your business. We take the searching,
              negotiating, and paperwork off your plate.
            </p>
            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
              {SERVICES.map((s) => (
                <article key={s.title} className="surface-card group p-6 transition-colors hover:border-primary/50">
                  <s.icon className="size-6 text-primary" aria-hidden />
                  <h3 className="mt-4 text-lg font-semibold">{s.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{s.text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* WHY CHOOSE US */}
        <section className="bg-[var(--surface)] py-24">
          <div className="container-page grid items-center gap-14 lg:grid-cols-2">
            <div>
              <img src={dock} alt="Semi-trucks loading at a distribution center dock" loading="lazy" width={1920} height={1080} className="h-[30rem] w-full rounded-lg object-cover" />
            </div>
            <div>
              <p className="eyebrow">Why Choose Us</p>
              <h2 className="mt-4 text-4xl font-bold md:text-5xl">
                Your Truck. Your Business. Our Dispatch Support.
              </h2>
              <ul className="mt-8 grid gap-3 sm:grid-cols-2">
                {WHY.map((item) => (
                  <li key={item} className="flex items-start gap-3 text-sm text-muted-foreground">
                    <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section id="how-it-works" className="scroll-mt-24 py-24">
          <div className="container-page">
            <p className="eyebrow">How It Works</p>
            <h2 className="mt-4 text-4xl font-bold md:text-5xl">Four Steps to Booked Freight</h2>
            <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
              {STEPS.map((s) => (
                <article key={s.n} className="surface-card relative overflow-hidden p-7">
                  <span className="font-[family-name:var(--font-display)] text-5xl font-bold text-primary/25">
                    {s.n}
                  </span>
                  <h3 className="mt-3 text-xl font-semibold">{s.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{s.text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* EQUIPMENT */}
        <section id="equipment" className="scroll-mt-24 bg-[var(--surface)] py-24">
          <div className="container-page">
            <p className="eyebrow">Truck Types</p>
            <h2 className="mt-4 text-4xl font-bold md:text-5xl">Equipment We Dispatch</h2>
            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {EQUIPMENT.map((e) => (
                <article key={e.name} className="surface-card p-6 transition-colors hover:border-primary/50">
                  <e.icon className="size-6 text-primary" aria-hidden />
                  <h3 className="mt-4 text-lg font-semibold">{e.name}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{e.text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* BENEFITS */}
        <section className="py-24">
          <div className="container-page">
            <p className="eyebrow">Driver Benefits</p>
            <h2 className="mt-4 text-4xl font-bold md:text-5xl">Less Time Searching. More Time Hauling.</h2>
            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {BENEFITS.map((b) => (
                <article key={b.title} className="surface-card border-l-4 border-l-primary p-6">
                  <h3 className="text-lg font-semibold">{b.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{b.text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="relative overflow-hidden">
          <img src={ctaHighway} alt="Semi-truck on an open highway at dusk" loading="lazy" width={1920} height={912} className="absolute inset-0 size-full object-cover" />
          <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
          <div className="container-page relative py-28 text-center">
            <h2 className="mx-auto max-w-3xl text-4xl font-bold md:text-6xl">
              Ready to Put Your Truck to Work?
            </h2>
            <p className="mx-auto mt-5 max-w-xl text-muted-foreground">
              Let us handle the freight search and dispatch support while you focus on hauling.
            </p>
            <a href="#contact" className="btn-base btn-primary mt-8">
              Start Dispatching <ArrowRight className="size-4" aria-hidden />
            </a>
          </div>
        </section>

        {/* ABOUT */}
        <section id="about" className="scroll-mt-24 py-24">
          <div className="container-page grid items-center gap-14 lg:grid-cols-2">
            <div>
              <p className="eyebrow">About Us</p>
              <h2 className="mt-4 text-4xl font-bold md:text-5xl">Built for Carriers, Run by Dispatchers</h2>
              <p className="mt-6 text-muted-foreground">
                 LRS Logistics Group provides freight dispatching support to owner-operators
                and small trucking companies across the lower 48. We know what a wasted day costs a
                one-truck operation, so we treat every load like it's our own revenue on the line.
              </p>
              <p className="mt-4 text-muted-foreground">
                Our dispatchers work the boards, build relationships with brokers, and stay
                responsive during business hours. No call-center scripts, no guessing who's handling
                your truck — just consistent, professional support that keeps your wheels turning
                and your paperwork in order.
              </p>
              <div className="mt-10 grid grid-cols-3 gap-6">
                {[
                  { k: "48", v: "States covered" },
                  { k: "8", v: "Equipment types" },
                  { k: "1:1", v: "Dedicated dispatcher" },
                ].map((s) => (
                  <div key={s.v}>
                    <p className="font-[family-name:var(--font-display)] text-4xl font-bold text-primary">
                      {s.k}
                    </p>
                    <p className="text-sm text-muted-foreground">{s.v}</p>
                  </div>
                ))}
              </div>
            </div>
            <img src={dock} alt="Trucks staged at a freight distribution center" loading="lazy" width={1280} height={960} className="h-[26rem] w-full rounded-lg object-cover" />
          </div>
        </section>

        {/* MEET THE OWNER */}
        <section id="owner" className="scroll-mt-24 bg-[var(--surface)] py-24">
          <div className="container-page grid items-start gap-12 lg:grid-cols-[1fr_1.4fr]">
            <div className="surface-card flex flex-col items-center gap-4 p-10 text-center lg:sticky lg:top-28">
              <span
                aria-hidden
                className="font-[family-name:var(--font-display)] flex size-24 items-center justify-center rounded-full border-2 border-primary/60 bg-background text-4xl font-bold text-primary"
              >
                TG
              </span>
              <div>
                <h3 className="text-2xl font-bold">Toniyah Garcia</h3>
                <p className="mt-1 text-sm tracking-[0.15em] text-primary uppercase">
                  Owner &amp; Founder | LRS Logistics Group
                </p>
              </div>
              <p className="font-[family-name:var(--font-display)] text-lg tracking-[0.25em] text-gradient-accent uppercase">
                All Things Possible.
              </p>
            </div>
            <div>
              <p className="eyebrow">Meet the Owner</p>
              <h2 className="mt-4 text-4xl font-bold md:text-5xl">Meet the Owner</h2>
              <p className="mt-6 text-muted-foreground">
                Welcome to LRS Logistics Group! My name is Toniyah Garcia, and I am the proud owner
                and founder of LRS Logistics Group.
              </p>
              <p className="mt-4 text-muted-foreground">
                I created LRS Logistics Group with one goal in mind: to provide dependable,
                professional, and organized dispatching support that helps carriers stay focused on
                what matters most — keeping their trucks moving and growing their business.
              </p>
              <p className="mt-4 text-muted-foreground">
                As an entrepreneur, I understand the importance of communication, reliability,
                organization, and having someone in your corner who takes your business seriously.
                My goal is to build long-term relationships with the carriers we serve while
                assisting with load searching, rate negotiations, broker communication, paperwork,
                and day-to-day dispatching needs.
              </p>
              <p className="mt-4 text-muted-foreground">
                At LRS Logistics Group, we believe in <strong className="text-foreground">professional service, strong communication, and creating opportunities for growth.</strong>
              </p>
              <p className="mt-6 font-[family-name:var(--font-display)] text-lg font-bold tracking-[0.2em] text-gradient-accent uppercase">
                All Things Possible.
              </p>
            </div>
          </div>
        </section>

        <ContactSection />

        {/* FAQ */}
        <section id="faqs" className="scroll-mt-24 py-24">
          <div className="container-page max-w-3xl">
            <p className="eyebrow">FAQs</p>
            <h2 className="mt-4 text-4xl font-bold md:text-5xl">Dispatch Questions, Answered</h2>
            <Accordion type="single" collapsible className="mt-10">
              {FAQS.map((f) => (
                <AccordionItem key={f.q} value={f.q}>
                  <AccordionTrigger className="text-left text-base font-semibold">
                    {f.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>
      </main>

      <footer className="border-t border-border bg-[var(--surface)] py-16">
        <div className="container-page grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
             <a href="#home" aria-label="LRS Logistics Group home" className="inline-block">
               <img
                 src={logoAsset.url}
                 alt="LRS Logistics Group"
                 width={800}
                 height={768}
                 className="h-28 w-auto object-contain"
               />
             </a>
            <p className="mt-5 text-sm text-muted-foreground">
              Professional freight dispatching for owner-operators and small trucking companies. We
              keep your truck moving while you focus on the road.
            </p>
            <div className="mt-5 flex gap-3">
              {[Facebook, Instagram, Linkedin, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#home"
                  aria-label="Social media"
                  className="rounded-md border border-border p-2 text-muted-foreground transition-colors hover:border-primary hover:text-primary"
                >
                  <Icon className="size-4" aria-hidden />
                </a>
              ))}
            </div>
          </div>

          <nav aria-label="Footer navigation">
            <h3 className="text-sm tracking-[0.2em]">Navigation</h3>
            <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
              {[
                ["Home", "#home"],
                ["About Us", "#about"],
                ["Dispatch Services", "#services"],
                ["How It Works", "#how-it-works"],
                ["Truck Types", "#equipment"],
                ["FAQs", "#faqs"],
                ["Contact Us", "#contact"],
              ].map(([label, href]) => (
                <li key={href}>
                  <a href={href} className="hover:text-primary">
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h3 className="text-sm tracking-[0.2em]">Services</h3>
            <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
              {SERVICES.slice(0, 7).map((s) => (
                <li key={s.title}>
                  <a href="#services" className="hover:text-primary">
                    {s.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm tracking-[0.2em]">Contact</h3>
            <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
              <li>(866) 852-4226</li>
              <li>info@lrslogisticsgroup.com</li>
              <li className="pt-2 font-medium text-foreground">Business Hours</li>
              <li>Monday – Friday</li>
              <li>8:00 AM – 6:00 PM</li>
            </ul>
            <a href="#contact" className="btn-base btn-primary mt-5 w-full">
              Get Started
            </a>
          </div>
        </div>
        <div className="container-page mt-12 border-t border-border pt-6 text-center text-xs text-muted-foreground">
           © {new Date().getFullYear()} LRS Logistics Group. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
