import { useState, type FormEvent } from "react";
import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { toast } from "sonner";

const TRUCK_TYPES = [
  "Dry Van",
  "Reefer",
  "Flatbed",
  "Step Deck",
  "Power Only",
  "Box Truck",
  "Hotshot",
  "Straight Truck",
];

export function ContactSection() {
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    const form = e.currentTarget;
    setTimeout(() => {
      setSubmitting(false);
      form.reset();
      toast.success("Request received!", {
        description:
          "Thank you for reaching out. You will be contacted within the next 24 hours regarding your request for dispatch services.",
      });
    }, 600);
  };

  const field =
    "w-full rounded-md border border-input bg-background/60 px-4 py-3 text-sm text-foreground outline-none transition placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-ring/40";

  return (
    <section id="contact" className="scroll-mt-24 bg-[var(--surface)] py-24">
      <div className="container-page grid gap-12 lg:grid-cols-[1fr_1.15fr]">
        <div>
          <p className="eyebrow">Contact Us</p>
          <h2 className="mt-4 text-4xl font-bold md:text-5xl">Request Dispatch Services</h2>
          <p className="mt-5 max-w-md text-muted-foreground">
            Tell us about your equipment and lanes. We'll follow up with a dispatch plan built
            around how you like to run.
          </p>

          <div className="mt-10 space-y-4">
            {[
              {
                icon: Clock,
                title: "Dispatch Hours",
                lines: ["Monday – Friday", "8:00 AM – 6:00 PM"],
              },
              { icon: Phone, title: "Phone", lines: ["(866) 852-4226"] },
              { icon: Mail, title: "Email", lines: ["info@lrslogisticsgroup.com"] },
              { icon: MapPin, title: "Operating", lines: ["48 states, coast to coast"] },
            ].map((item) => (
              <div key={item.title} className="surface-card flex gap-4 p-5">
                <item.icon className="mt-0.5 size-5 shrink-0 text-primary" aria-hidden />
                <div>
                  <p className="font-[family-name:var(--font-display)] text-sm uppercase tracking-[0.18em]">
                    {item.title}
                  </p>
                  {item.lines.map((l) => (
                    <p key={l} className="text-sm text-muted-foreground">
                      {l}
                    </p>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <form onSubmit={onSubmit} className="surface-card space-y-4 p-6 md:p-8">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="fullName" className="mb-2 block text-sm font-medium">
                Full Name
              </label>
              <input id="fullName" name="fullName" required className={field} placeholder="John Carter" />
            </div>
            <div>
              <label htmlFor="company" className="mb-2 block text-sm font-medium">
                Company Name
              </label>
              <input id="company" name="company" className={field} placeholder="Carter Trucking LLC" />
            </div>
            <div>
              <label htmlFor="phone" className="mb-2 block text-sm font-medium">
                Phone Number
              </label>
              <input id="phone" name="phone" type="tel" required className={field} placeholder="(555) 000-0000" />
            </div>
            <div>
              <label htmlFor="email" className="mb-2 block text-sm font-medium">
                Email
              </label>
              <input id="email" name="email" type="email" required className={field} placeholder="you@email.com" />
            </div>
            <div>
              <label htmlFor="trucks" className="mb-2 block text-sm font-medium">
                Number of Trucks
              </label>
              <input id="trucks" name="trucks" type="number" min="1" defaultValue={1} className={field} />
            </div>
            <div>
              <label htmlFor="truckType" className="mb-2 block text-sm font-medium">
                Truck Type
              </label>
              <select id="truckType" name="truckType" className={field} defaultValue="Dry Van">
                {TRUCK_TYPES.map((t) => (
                  <option key={t} value={t} className="bg-card">
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label htmlFor="message" className="mb-2 block text-sm font-medium">
              Message
            </label>
            <textarea
              id="message"
              name="message"
              rows={4}
              className={field}
              placeholder="Preferred lanes, home time, target rates..."
            />
          </div>
          <button type="submit" disabled={submitting} className="btn-base btn-primary w-full disabled:opacity-70">
            {submitting ? "Sending..." : "Request Dispatch Services"}
          </button>
          <p className="text-center text-xs text-muted-foreground">
            We respond during dispatch hours, Monday–Friday 8:00 AM–6:00 PM.
          </p>
        </form>
      </div>
    </section>
  );
}
